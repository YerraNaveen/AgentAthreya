package com.agentathreya.conversationservice.service;


import java.time.LocalDateTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.agentathreya.conversationservice.entity.ChatMessage;
import com.agentathreya.conversationservice.repository.ChatRepository;

@Service
public class ChatService {

    private static final Logger logger = LoggerFactory.getLogger(ChatService.class);

    @Autowired
    private ChatRepository chatRepository;

    public ChatMessage saveMessage(String userMessage) {
    	String username = ((UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUsername();
        logger.info("Saving user message: {}", userMessage);
        
        ChatMessage chatMessage = ChatMessage.builder()
                .sender(username)
                .message(userMessage)
                .timestamp(LocalDateTime.now())
                .build();

        chatMessage = chatRepository.save(chatMessage);
        logger.info("Message saved with ID: {}", chatMessage.getId());
        return chatMessage;
    }

    public List<ChatMessage> getChatHistory() {
        logger.info("Fetching full chat history");
        List<ChatMessage> history = chatRepository.findAll();
        logger.info("Total messages fetched: {}", history.size());
        return history;
    }
}

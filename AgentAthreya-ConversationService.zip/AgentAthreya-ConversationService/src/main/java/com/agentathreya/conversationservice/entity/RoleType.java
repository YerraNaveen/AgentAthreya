package com.agentathreya.conversationservice.entity;

public enum RoleType {
    ROLE_USER,
    ROLE_ADMIN
}

package com.agentathreya.conversationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgentAthreyaConversationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
